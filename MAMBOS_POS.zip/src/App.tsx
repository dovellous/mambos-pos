import React from 'react';
import './App.scss';
import CashierPOS from "./CashierPOS";

function App() {
  return (
    <CashierPOS />
  );  
}

export default App;